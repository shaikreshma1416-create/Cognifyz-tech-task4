const app = document.getElementById("app");

// ROUTER
function router() {
  const route = location.hash || "#home";

  if (route === "#home") home();
  else if (route === "#register") register();
  else if (route === "#dashboard") dashboard();
}

window.addEventListener("hashchange", router);
window.addEventListener("load", router);

// HOME
function home() {
  app.innerHTML = `
    <h2>Home Page</h2>
    <p>Welcome to Simple SPA 🚀</p>
  `;
}

// DASHBOARD
function dashboard() {
  app.innerHTML = `
    <h2>Dashboard</h2>
    <p id="msg">No data</p>
    <button onclick="loadData()">Click Me</button>
  `;
}

window.loadData = function () {
  document.getElementById("msg").innerText =
    "Data Loaded Successfully!";
};

// REGISTER
function register() {
  app.innerHTML = `
    <h2>Register</h2>

    <input id="user" placeholder="Username">
    <input id="pass" type="password" placeholder="Password">

    <p id="hint"></p>
    <button onclick="submitForm()">Submit</button>

    <p id="error"></p>
  `;

  document.getElementById("pass").addEventListener("input", function () {
    document.getElementById("hint").innerText =
      "Strength: " + passwordStrength(this.value);
  });
}

// PASSWORD STRENGTH
function passwordStrength(p) {
  let score = 0;

  if (p.length >= 8) score++;
  if (/[A-Z]/.test(p)) score++;
  if (/[0-9]/.test(p)) score++;
  if (/[@$!%*?&]/.test(p)) score++;

  if (score <= 1) return "Weak";
  if (score <= 3) return "Medium";
  return "Strong";
}

// SUBMIT
window.submitForm = function () {
  let user = document.getElementById("user").value;
  let pass = document.getElementById("pass").value;
  let error = document.getElementById("error");

  error.style.color = "red";

  if (user.length < 3) {
    error.innerText = "Username must be at least 3 letters";
    return;
  }

  if (!validatePassword(pass)) {
    error.innerText = "Password weak (A-Z, 0-9, symbol needed)";
    return;
  }

  error.style.color = "green";
  error.innerText = "Success ✔ Registered!";
};

// PASSWORD VALIDATION
function validatePassword(p) {
  return (
    p.length >= 8 &&
    /[A-Z]/.test(p) &&
    /[0-9]/.test(p) &&
    /[@$!%*?&]/.test(p)
  );
}